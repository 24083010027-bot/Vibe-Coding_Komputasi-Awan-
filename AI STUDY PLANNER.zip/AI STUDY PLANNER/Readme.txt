Aplikasi SmartDay AI Planner. Dibuat dengan HTML/Tailwind dan tersambung ke Google AI Studio menggunakan model Gemini 1.5 Flash

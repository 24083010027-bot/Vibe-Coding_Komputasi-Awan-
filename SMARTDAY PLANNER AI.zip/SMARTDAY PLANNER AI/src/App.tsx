import { useState } from 'react';

// Definisikan tipe data untuk Schedule Item
interface ScheduleItem {
  time: string;
  activity: string;
  category: 'focus' | 'break' | 'leisure';
  duration?: string;
}

export default function App() {
  const [rawTasks, setRawTasks] = useState('');
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [toasts, setToasts] = useState<{ id: number; message: string; type: 'success' | 'error' | 'info' }[]>([]);

  const GEMINI_API_KEY = "AQ.Ab8RN6IW7bB80vVkvRwnH8DWqxlz_xkiVqThoCblHex1nk-SCw";

  // Fungsi Kustom Toast Notification
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id));
    }, 5000);
  };

  // Fungsi Mencari Pola Waktu Lokal (Fallback Engine)
  const runResilientLocalEngine = (inputText: string) => {
    const localSchedule: ScheduleItem[] = [];
    const timePatterns = [
      { regex: /(?:bangun|pagi|jam\s*([6-9]|10))/gi, defaultTime: "08:00", duration: "1 Jam", cat: "focus" as const },
      { regex: /(?:kuliah|belajar|tugas|kerja|jam\s*(8|9|10|11))/gi, defaultTime: "09:30", duration: "2 Jam", cat: "focus" as const },
      { regex: /(?:siang|makan|istirahat|jam\s*(12|13|14))/gi, defaultTime: "12:00", duration: "1 Jam", cat: "break" as const },
      { regex: /(?:cuci|sore|olahraga|gym|jam\s*(15|16|17))/gi, defaultTime: "16:00", duration: "45 Menit", cat: "leisure" as const },
      { regex: /(?:malam|nonton|game|tidur|jam\s*(19|20|21|22))/gi, defaultTime: "20:00", duration: "2 Jam", cat: "leisure" as const }
    ];

    const segments = inputText.split(/[,.]| lalu | kemudian | terus /g);

    segments.forEach((segment, index) => {
      const cleanSegment = segment.trim();
      if (cleanSegment.length < 4) return;

      let matchedTime = "";
      let matchedCat: 'focus' | 'break' | 'leisure' = "leisure";
      let matchedDuration = "1 Jam";

      const digitalTimeMatch = cleanSegment.match(/(\d{1,2})[:.](\d{2})/);
      if (digitalTimeMatch) {
        matchedTime = `${digitalTimeMatch[1].padStart(2, '0')}:${digitalTimeMatch[2]}`;
      }

      for (const pattern of timePatterns) {
        if (pattern.regex.test(cleanSegment)) {
          if (!matchedTime) matchedTime = pattern.defaultTime;
          matchedCat = pattern.cat;
          matchedDuration = pattern.duration;
          break;
        }
      }

      if (!matchedTime) {
        const estimatedHour = 8 + (index * 2);
        matchedTime = `${String(estimatedHour).padStart(2, '0')}:00`;
      }

      localSchedule.push({
        time: matchedTime,
        activity: cleanSegment.charAt(0).toUpperCase() + cleanSegment.slice(1),
        category: matchedCat,
        duration: matchedDuration
      });
    });

    localSchedule.sort((a, b) => a.time.localeCompare(b.time));

    if (localSchedule.length > 0) {
      setSchedule(localSchedule);
      showToast("Sistem mendeteksi limit jaringan. Beralih ke Smart-Local Engine.", "info");
    } else {
      tryDemo();
    }
  };

  // Fungsi Mengoptimasi Jadwal ke Gemini API
  const optimizeSchedule = async () => {
    if (!rawTasks.trim()) {
      showToast("Tulis daftar aktivitas acak Anda terlebih dahulu!", "error");
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: `Rapikan kronologis aktivitas ini: "${rawTasks}". Balas HANYA dengan format raw JSON array tanpa penutup markdown \`\`\`json: [{"time":"HH:MM","activity":"...","category":"focus|break|leisure","duration":"..."}]`
            }]
          }]
        })
      });

      if (!response.ok) throw new Error("API Restricted or Invalid Key");

      const data = await response.json();
      let text = data.candidates[0].content.parts[0].text;
      text = text.replace(/```json|```/g, '').trim();

      const parsedSchedule = JSON.parse(text);
      setSchedule(parsedSchedule);
      showToast("Jadwal sukses dirapikan via Gemini API! ⚡", "success");
    } catch (e) {
      console.warn("Mengaktifkan Mesin Cerdas Cadangan (Resilient Local Engine)...");
      runResilientLocalEngine(rawTasks);
    } finally {
      setIsLoading(false);
    }
  };

  // Fungsi Memuat Demo
  const tryDemo = () => {
    const demoData: ScheduleItem[] = [
      { time: "08:00", activity: "Kuliah Komputasi Awan (Ruang Kuliah 4.1)", category: "focus", duration: "2 Jam" },
      { time: "10:15", activity: "Istirahat Sejenak & Mengopi", category: "break", duration: "15 Menit" },
      { time: "11:00", activity: "Mencuci Baju & Beres-Beres Kosan", category: "leisure", duration: "45 Menit" },
      { time: "14:00", activity: "Mengerjakan Tugas Projek #JuaraVibeCoding", category: "focus", duration: "3 Jam" },
      { time: "19:00", activity: "Makan Malam & Santai Menonton Film", category: "leisure", duration: "2 Jam" }
    ];
    setSchedule(demoData);
    showToast("Demo sukses dimuat! Silakan ketik aktivitas Anda untuk mencoba AI.", "success");
  };

  return (
    <div className="relative min-h-screen w-full bg-[#020617] text-[#f1f5f9] py-12 px-4 flex flex-col items-center justify-start font-['Plus_Jakarta_Sans'] overflow-x-hidden selection:bg-indigo-500/30">
      {/* Glow Blobs */}
      <div className="absolute w-[500px] h-[500px] rounded-full bg-indigo-600/10 blur-[120px] top-[-100px] right-[-100px] pointer-events-none z-0"></div>
      <div className="absolute w-[500px] h-[500px] rounded-full bg-emerald-600/10 blur-[120px] bottom-[-100px] left-[-100px] pointer-events-none z-0"></div>

      {/* Toast Container */}
      <div className="fixed top-5 right-5 z-50 flex flex-col gap-3 max-w-sm w-full">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`p-4 rounded-xl border bg-slate-950/75 backdrop-blur-md flex items-center gap-3 shadow-2xl transition-all duration-300 ${
              toast.type === 'error' ? 'border-rose-500 bg-rose-950/20' : toast.type === 'info' ? 'border-indigo-500 bg-indigo-950/20' : 'border-emerald-500 bg-emerald-950/20'
            }`}
          >
            <i className={`fa-solid ${toast.type === 'error' ? 'fa-circle-exclamation text-rose-400' : toast.type === 'info' ? 'fa-circle-info text-indigo-400' : 'fa-circle-check text-emerald-400'} text-lg`}></i>
            <div className="text-sm font-medium text-gray-200">{toast.message}</div>
          </div>
        ))}
      </div>

      {/* Kontainer Utama Dipastikan Rata Tengah Total */}
      <div className="max-w-3xl w-full flex flex-col items-center justify-start relative z-10">
        
        {/* Top Bar */}
        <div className="flex justify-between items-center w-full mb-10 px-2">
          <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/75 backdrop-blur-md border border-indigo-500/30 text-indigo-400 text-xs font-bold uppercase tracking-wider">
            <i className="fa-solid fa-sparkles animate-pulse"></i> Hybrid AI Core Active
          </div>
          <div className="text-[11px] text-gray-500 font-mono">v1.2-resilient</div>
        </div>

        {/* Header Section */}
        <header className="text-center mb-12 flex flex-col items-center w-full">
          <h1 
            className="font-['Space_Grotesk'] text-5xl md:text-6xl font-bold tracking-tight bg-gradient-to-r from-indigo-300 via-emerald-300 to-indigo-300 mb-4 block w-fit"
            style={{ WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}
          >
            SMARTDAY AI
          </h1>
          <p className="text-gray-400 text-sm md:text-base max-w-md mx-auto leading-relaxed px-4">
            Penjadwal harian pintar yang merapikan segala kekacauan aktivitas Anda secara instan dan efisien.
          </p>
        </header>

        {/* Main Card Input Box */}
        <main className="bg-slate-900/75 backdrop-blur-md border border-white/5 rounded-3xl p-6 md:p-8 mb-8 shadow-2xl w-full">
          <label htmlFor="rawTasksInput" className="block text-xs font-bold uppercase tracking-widest text-indigo-400 mb-3 flex items-center gap-2">
            <i className="fa-solid fa-pen-fancy"></i> Curahkan Rencana Aktivitas Anda
          </label>
          <textarea
            id="rawTasksInput"
            rows={4}
            value={rawTasks}
            onChange={(e) => setRawTasks(e.target.value)}
            placeholder="Contoh: besok bangun pagi jam 6 olahraga, terus jam 8 kuliah komputasi awan, siang mau nyuci baju, malemnya jam 7 ngerjain tugas, terus tidur jam 10 malam..."
            className="w-full p-4 bg-slate-900/60 border border-slate-700/50 rounded-2xl focus:border-emerald-500 focus:outline-none text-gray-100 placeholder-gray-600 text-base mb-5 resize-none transition-all duration-300 focus:ring-2 focus:ring-emerald-500/20"
          ></textarea>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button
              onClick={optimizeSchedule}
              disabled={isLoading}
              className="py-4 bg-gradient-to-r from-indigo-500 to-emerald-500 hover:opacity-90 active:scale-95 text-white rounded-2xl font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition-all duration-300 disabled:opacity-50"
            >
              <span>{isLoading ? "Meracik Jadwal..." : "Optimasi Jadwal ⚡"}</span>
              {isLoading && <i className="fa-solid fa-circle-notch animate-spin"></i>}
            </button>
            <button
              onClick={tryDemo}
              className="py-4 bg-slate-800/40 hover:bg-slate-800 text-gray-300 rounded-2xl font-bold text-sm border border-slate-700/50 flex items-center justify-center gap-2 transition-all duration-300"
            >
              <i className="fa-solid fa-wand-magic-sparkles text-emerald-400"></i> Lihat Contoh Demo
            </button>
          </div>
        </main>

        {/* Timeline Result Container */}
        <section className="space-y-4 min-h-[100px] w-full">
          {schedule.length === 0 ? (
            <div className="text-center py-8 text-gray-600 text-sm border-2 border-dashed border-slate-800/80 rounded-2xl w-full">
              Belum ada jadwal yang dioptimasi. Tulis rencana Anda di atas!
            </div>
          ) : (
            schedule.map((item, index) => {
              let theme = 'border-l-indigo-500 bg-indigo-500/5';
              let icon = 'fa-couch text-indigo-400';

              if (item.category === 'focus') {
                theme = 'border-l-rose-500 bg-rose-500/5';
                icon = 'fa-brain text-rose-400';
              } else if (item.category === 'break') {
                theme = 'border-l-emerald-500 bg-emerald-500/5';
                icon = 'fa-mug-hot text-emerald-400';
              }

              return (
                <div key={index} className={`bg-slate-900/75 backdrop-blur-md border border-white/5 p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center gap-4 border-l-4 ${theme} transition-all hover:translate-x-1 duration-200 w-full text-left`}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-center">
                      <i className={`fa-solid ${icon}`}></i>
                    </div>
                    <div className="text-xl font-bold text-gray-100 min-w-[70px]">{item.time}</div>
                  </div>
                  <div className="flex-grow">
                    <h4 className="font-bold text-sm text-gray-200">{item.activity}</h4>
                    <p className="text-[10px] text-gray-500 flex items-center gap-1 mt-1">
                      <i className="fa-regular fa-clock"></i> Estimasi Durasi: {item.duration || "N/A"}
                    </p>
                  </div>
                  <div className="self-start sm:self-center">
                    <span className="text-[9px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-gray-300">
                      {item.category}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </section>
      </div>
    </div>
  );
}